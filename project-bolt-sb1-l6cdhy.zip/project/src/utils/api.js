import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || '/.netlify/functions';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const createCheckoutSession = async (priceId) => {
  try {
    const response = await api.post('/create-checkout', { priceId });
    return response.data;
  } catch (error) {
    console.error('Erreur création session:', error);
    throw error;
  }
};