import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

function PaymentSuccess() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full"
      >
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
            <svg
              className="h-6 w-6 text-green-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h2 className="mt-4 text-2xl font-bold text-gray-900">
            Paiement réussi !
          </h2>
          <p className="mt-2 text-gray-600">
            Merci pour votre abonnement. Votre compte a été mis à jour avec les nouveaux privilèges.
          </p>
          <div className="mt-6">
            <Link
              to="/forum"
              className="inline-block bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors duration-200"
            >
              Accéder au Forum
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default PaymentSuccess;