import React from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { motion } from 'framer-motion';
import { createCheckoutSession } from '../utils/api';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const plans = [
  {
    name: 'Gratuit',
    price: '0€',
    features: [
      'Accès au forum en lecture seule',
      '5 messages par mois',
      'Support communautaire'
    ],
    buttonText: 'Commencer',
    priceId: 'free'
  },
  {
    name: 'Pro',
    price: '9.99€',
    features: [
      'Messages illimités',
      'Accès aux sections premium',
      'Badge PRO',
      'Support prioritaire'
    ],
    buttonText: 'Devenir Pro',
    priceId: process.env.VITE_STRIPE_PRO_PRICE_ID
  },
  {
    name: 'Expert',
    price: '29.99€',
    features: [
      'Tout le plan Pro',
      'Sessions de mentorat',
      'Ressources exclusives',
      'Accès anticipé aux nouveautés'
    ],
    buttonText: 'Devenir Expert',
    priceId: process.env.VITE_STRIPE_EXPERT_PRICE_ID
  }
];

function Pricing() {
  const handleSubscription = async (priceId) => {
    if (priceId === 'free') {
      // Gérer l'inscription gratuite
      return;
    }

    try {
      const stripe = await stripePromise;
      const { id: sessionId } = await createCheckoutSession(priceId);
      
      const { error } = await stripe.redirectToCheckout({ sessionId });
      
      if (error) {
        console.error('Erreur redirection:', error);
      }
    } catch (error) {
      console.error('Erreur souscription:', error);
    }
  };

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Plans et Tarifs
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Choisissez le plan qui correspond à vos besoins
          </p>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-3">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-lg overflow-hidden"
            >
              <div className="px-6 py-8">
                <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                <p className="mt-4 text-4xl font-extrabold text-gray-900">{plan.price}</p>
                <p className="mt-1 text-sm text-gray-500">/mois</p>

                <ul className="mt-6 space-y-4">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span className="ml-2 text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleSubscription(plan.priceId)}
                  className="mt-8 w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors duration-200"
                >
                  {plan.buttonText}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Pricing;